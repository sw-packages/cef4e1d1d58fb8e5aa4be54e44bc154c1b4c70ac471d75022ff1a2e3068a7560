package Foo;
$Foo::VERSION = '0.1';
1;
